/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var llrpReader = require('./LLRPReader');

var r = new llrpReader.LLRPReader( );

r.start({}, null,{port:5084, ipaddress:"192.168.1.147"}, function(err){
    var e = err;
//    s.stop( function(err){
//        e = err;
//    });
});
