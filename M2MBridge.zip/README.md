M2MBridge
==============

This is M2MBridge a software bridge to integrate existing M2M and other device
oriented protocols with AMTech IoT domain application protocol.


